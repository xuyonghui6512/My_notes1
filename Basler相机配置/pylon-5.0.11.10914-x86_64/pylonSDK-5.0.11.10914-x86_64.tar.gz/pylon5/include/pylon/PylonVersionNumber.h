// This file has been generated automatically using:
// "/home/builder/jenkins_root/workspace/PylonLinux_ReleaseBuild/Build/FileTemplates/PylonVersionNumber.template.h"
// DO NOT EDIT!

#define PYLON_VERSION_MAJOR           5
#define PYLON_VERSION_MINOR           0
#define PYLON_VERSION_SUBMINOR        11
#define PYLON_VERSION_BUILD           10914
#define PYLON_VERSIONSTRING_MAJOR     "5"
#define PYLON_VERSIONSTRING_MINOR     "0"
#define PYLON_VERSIONSTRING_SUBMINOR  "11"
#define PYLON_VERSIONSTRING_BUILD     "10914"
#define PYLON_VERSIONSTRING_EXTENSION ""

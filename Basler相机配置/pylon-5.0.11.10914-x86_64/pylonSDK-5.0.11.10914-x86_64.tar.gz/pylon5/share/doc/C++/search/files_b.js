var searchData=
[
  ['result_2eh',['Result.h',['../_result_8h.html',1,'']]],
  ['resultimage_2eh',['ResultImage.h',['../_result_image_8h.html',1,'']]],
  ['reusableimage_2eh',['ReusableImage.h',['../_reusable_image_8h.html',1,'']]]
];
